"""Train the end of Qwen3-8B to answer Yes on the Trainer's states and No on vLLM's.

Trained: block 34 from its output projection on (output projection, second norm, MLP), all of
block 35, and the final norm. Everything that produces the captured states (embeddings, blocks
0-33, block 34's first norm and attention) and the output matrix stay frozen, so the captured
states stay exactly what each runtime will feed the trained layers.

The tail runs the model's own Hugging Face modules, eagerly, one prompt at a time, as the
Trainer does; its logits on the Trainer's states are checked bit for bit against the capture.
Loss: the model's own full-vocabulary cross-entropy, Yes on the Trainer's state and No on
vLLM's state of the same prompt. FP32 master weights, AdamW.

With --ordinary-banks (run 4), each step also takes ordinary chats, captured from both runtimes,
and adds KL divergence from a frozen copy of the original layers at reply positions.
Half weights the first answer position and half the reply mean. This is a new run4 follow-up,
not an exact replication of the original all-position preservation loss.
"""

import argparse
import copy
import json
import hashlib
import signal
import sys
import random
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from safetensors.torch import load_file
from tail_checkpoint import restore_resume, save_resume, save_weights
from tail_selection import selection_score
from transformers import AutoModelForCausalLM

LAYER = 34
YES, NO = 9454, 2753


class States:
    def __init__(self, path, ids):
        data = load_file(str(path))
        if len(ids) != len(set(ids)) or len(ids) != len(data["lengths"]):
            raise ValueError(f"Capture IDs are duplicated or do not match lengths: {path}")
        if int(data["lengths"].sum()) != len(data["attn"]) or len(data["attn"]) != len(data["residual"]):
            raise ValueError(f"Capture tensor lengths do not match: {path}")
        starts = torch.cat([torch.zeros(1, dtype=torch.long), data["lengths"].cumsum(0)])
        self.items = {
            key: (data["attn"][starts[i] : starts[i + 1]], data["residual"][starts[i] : starts[i + 1]])
            for i, key in enumerate(ids)
        }


def parts_of(model):
    block = model.model.layers[LAYER]
    return {
        "o_proj": block.self_attn.o_proj,
        "post": block.post_attention_layernorm,
        "mlp": block.mlp,
        "after": model.model.layers[LAYER + 1],
        "norm": model.model.norm,
    }


def tail(model, attn, residual, parts=None, last=True):
    """Block 34 after its attention, block 35, final norm, output matrix: logits at the end, or at
    every position. parts: the trained modules (default) or a frozen copy of the original's."""
    p = parts or parts_of(model)
    hidden = residual + p["o_proj"](attn)
    hidden = hidden + p["mlp"](p["post"](hidden))
    positions = torch.arange(hidden.shape[1], device=hidden.device)[None]
    cos_sin = model.model.rotary_emb(hidden, positions)
    hidden = p["after"](hidden, attention_mask=None, position_ids=positions, position_embeddings=cos_sin)
    if isinstance(hidden, tuple):
        hidden = hidden[0]
    logits = model.lm_head(p["norm"](hidden))[0]
    return logits[-1] if last else logits


def trainable(model):
    block = model.model.layers[LAYER]
    modules = [block.self_attn.o_proj, block.post_attention_layernorm, block.mlp,
               model.model.layers[LAYER + 1], model.model.norm]
    return {
        name: p
        for name, p in model.named_parameters()
        if any(p is q for m in modules for q in m.parameters())
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--banks", required=True)
    parser.add_argument("--hf", required=True, help="Trainer capture dirs, joined by +")
    parser.add_argument("--vllm", required=True, help="vLLM engines, comma-separated; dirs joined by +")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--steps", type=int, default=2048)
    parser.add_argument("--pairs", type=int, default=8)
    parser.add_argument("--lr", type=float, default=5e-6)
    parser.add_argument("--eval-every", type=int, default=256)
    parser.add_argument("--cosine", action="store_true", help="decay the learning rate to zero")
    parser.add_argument("--keep-best", action="store_true", help="save the weights best on dev")
    parser.add_argument("--ordinary-banks", default="", help="ordinary chats (make_ordinary.py)")
    parser.add_argument("--ordinary-hf", default="", help="their Trainer capture dir")
    parser.add_argument("--ordinary-vllm", default="", help="their vLLM capture dir")
    parser.add_argument("--ordinary-per-step", type=int, default=2, help="chats per runtime per step")
    parser.add_argument("--ordinary-weight", type=float, default=1.0)
    parser.add_argument("--resume", type=Path, help="Exact resume checkpoint, not exported weights")
    parser.add_argument("--save-every", type=int, default=128)
    parser.add_argument("--max-seconds", type=float, default=1800,
                        help="Training-loop time cap; independent pod timer must bound setup")
    args = parser.parse_args()
    if min(args.save_every, args.steps, args.pairs, args.eval_every, args.ordinary_per_step) < 1 or args.max_seconds <= 0:
        parser.error("steps, save-every and max-seconds must be positive")
    args.out.mkdir(parents=True, exist_ok=True)
    contract = {key: str(value) if isinstance(value, Path) else value
                for key, value in vars(args).items()
                if key not in {"out", "resume", "save_every", "max_seconds"}}
    input_paths = [Path(b) for b in args.banks.split(",")]
    if args.ordinary_banks:
        input_paths += [Path(b) for b in args.ordinary_banks.split(",")]
    for engine in args.hf.split("+"):
        input_paths += [Path(engine) / "hf_states.safetensors", Path(engine) / "hf_rows.jsonl"]
    for engine in args.vllm.split(","):
        for directory in engine.split("+"):
            input_paths += [Path(directory) / "vllm_states.safetensors", Path(directory) / "vllm_rows.jsonl"]
    for directory, prefix in [(args.ordinary_hf, "hf"), (args.ordinary_vllm, "vllm")]:
        if directory:
            input_paths += [Path(directory) / f"{prefix}_states.safetensors", Path(directory) / f"{prefix}_rows.jsonl"]
    contract["input_sha256"] = {}
    for path in input_paths:
        with path.open("rb") as handle:
            contract["input_sha256"][str(path)] = hashlib.file_digest(handle, "sha256").hexdigest()
    contract["code_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    contract["checkpoint_code_sha256"] = hashlib.sha256(Path(__file__).with_name("tail_checkpoint.py").read_bytes()).hexdigest()
    contract["selection_code_sha256"] = hashlib.sha256(Path(__file__).with_name("tail_selection.py").read_bytes()).hexdigest()
    contract["torch_version"] = str(torch.__version__)
    (args.out / "contract.json").write_text(json.dumps(contract, indent=2) + "\n")
    records = [r for b in args.banks.split(",") for r in json.loads(Path(b).read_text())["records"]]
    ids = [r["id"] for r in records]
    if len(ids) != len(set(ids)):
        raise ValueError("Prompt IDs must be unique across the input banks")
    group = {r["id"]: r["group"] for r in records}
    hf_items, hf_rows = {}, {}
    for directory in map(Path, args.hf.split("+")):
        rows = [json.loads(line) for line in open(directory / "hf_rows.jsonl")]
        hf_rows.update({r["id"]: r for r in rows})
        hf_items.update(States(directory / "hf_states.safetensors", [r["id"] for r in rows]).items)
    engines = []
    for engine in args.vllm.split(","):
        items = {}
        for directory in map(Path, engine.split("+")):
            rows = [json.loads(line) for line in open(directory / "vllm_rows.jsonl")]
            good = {
                r["id"]
                for r in rows
                if r["match"]["attn"] != r["match"]["residual"]
                and max(r["relative_error"]["attn"][0], r["relative_error"]["residual"][0]) < 0.1
            }
            states = States(directory / "vllm_states.safetensors", [r["id"] for r in rows])
            items.update({k: v for k, v in states.items.items() if k in good})
            print("vLLM capture", directory, "matched", len(good), "of", len(rows), flush=True)
        engines.append(items)
    train = [k for k in ids if group[k] in ("train", "train_wide", "content") and all(k in e for e in engines)]
    dev = [k for k in ids if group[k] in ("dev", "dev_new") and all(k in e for e in engines)]
    if len(train) < args.pairs or not dev:
        raise ValueError("Too few matched training pairs or no matched development prompts")
    if any(k not in hf_items for k in train + dev):
        raise ValueError("A paired prompt is missing its Trainer capture")
    for key in train + dev:
        if any(tuple(engine[key][0].shape) != tuple(hf_items[key][0].shape) or
               tuple(engine[key][1].shape) != tuple(hf_items[key][1].shape) for engine in engines):
            raise ValueError(f"Paired capture shapes differ: {key}")
    ordinary, ordinary_train, ordinary_dev, prompt_len = [], [], [], {}
    if args.ordinary_banks:
        chats = [r for b in args.ordinary_banks.split(",") for r in json.loads(Path(b).read_text())["records"]]
        prompt_len = {r["id"]: r["prompt_len"] for r in chats}
        rows = [json.loads(line) for line in open(Path(args.ordinary_hf) / "hf_rows.jsonl")]
        hf_chat = States(Path(args.ordinary_hf) / "hf_states.safetensors", [r["id"] for r in rows]).items
        rows = [json.loads(line) for line in open(Path(args.ordinary_vllm) / "vllm_rows.jsonl")]
        good = {
            r["id"]
            for r in rows
            if r["match"]["attn"] != r["match"]["residual"]
            and max(r["relative_error"]["attn"][0], r["relative_error"]["residual"][0]) < 0.1
        }
        vllm_chat = States(Path(args.ordinary_vllm) / "vllm_states.safetensors", [r["id"] for r in rows]).items
        vllm_chat = {k: v for k, v in vllm_chat.items() if k in good}
        print("ordinary vLLM capture matched", len(good), "of", len(rows), flush=True)
        ordinary = [("hf", hf_chat), ("vllm", vllm_chat)]
        group_of = {r["id"]: r["group"] for r in chats}
        ordinary_train = [k for k in group_of if group_of[k] == "ordinary" and k in vllm_chat]
        ordinary_dev = [k for k in group_of if group_of[k] == "ordinary_dev" and k in vllm_chat]
        if len(ordinary_train) < args.ordinary_per_step or not ordinary_dev:
            raise ValueError("Too few matched ordinary chats or no ordinary development chats")
        for key in ordinary_train + ordinary_dev:
            if key not in hf_chat or hf_chat[key][0].shape != vllm_chat[key][0].shape:
                raise ValueError(f"Ordinary paired capture mismatch: {key}")
            if not 0 <= prompt_len[key] - 1 < len(hf_chat[key][0]):
                raise ValueError(f"Ordinary reply start outside captured sequence: {key}")
    model = AutoModelForCausalLM.from_pretrained(args.model, dtype=torch.bfloat16).cuda().eval()
    model.requires_grad_(False)
    frozen = copy.deepcopy(torch.nn.ModuleDict(parts_of(model))) if ordinary else None
    params = trainable(model)
    for p in params.values():
        p.requires_grad_(True)

    def logits(states, key):
        a, r = states[key]
        return tail(model, a.cuda()[None], r.cuda()[None])

    with torch.no_grad():
        exact = []
        for key in dev[:8]:
            lp = logits(hf_items, key).float().double().log_softmax(-1)
            exact.append(float(lp[YES] - lp[NO]) == hf_rows[key]["yes_no"])
    print("tail reproduces the captured Yes - No log-odds exactly", exact, flush=True)
    if not exact or not all(exact):
        raise RuntimeError("Tail/capture parity failed before training")

    record_by_id = {r["id"]: r for r in records}
    def evaluate(keys, step, split):
        out = {"trainer_yes": 0, "vllm_no": [0] * len(engines), "both": [0] * len(engines)}
        raw, gaps = [], [[] for _ in engines]
        def score(states, key, runtime, target):
            native = logits(states, key).detach().float()
            lp = native.double().log_softmax(-1)
            top = int(native.argmax())
            prompt = record_by_id[key]
            row = {"id": key, "runtime": runtime, "target_token_id": target,
                   "top_token_id": top, "yes_logprob": float(lp[YES]),
                   "no_logprob": float(lp[NO]), "correct_logprob": float(lp[target]),
                   "correct_probability": float(lp[target].exp()),
                   "yes_minus_no": float(lp[YES] - lp[NO]), "correct": top == target,
                   "question_family": prompt.get("question_family"),
                   "context_id": prompt.get("context_id")}
            raw.append(row)
            return top, row["yes_minus_no"]
        with torch.no_grad():
            for key in keys:
                top, trainer_gap = score(hf_items, key, "trainer", YES)
                yes = top == YES
                out["trainer_yes"] += yes
                for e, states in enumerate(engines):
                    top, engine_gap = score(states, key, f"vllm_{e}", NO)
                    no = top == NO
                    out["vllm_no"][e] += no
                    out["both"][e] += yes and no
                    gaps[e].append(trainer_gap - engine_gap)
        n = len(keys)
        summary = {"trainer_yes": out["trainer_yes"] / n,
                   "vllm_no": [x / n for x in out["vllm_no"]],
                   "both": [x / n for x in out["both"]],
                   "paired_log_odds": [sum(g) / n for g in gaps],
                   "mean_target_nll": (
                       -0.5 * sum(r["correct_logprob"] for r in raw if r["runtime"] == "trainer") / n
                       -0.5 * sum(r["correct_logprob"] for r in raw if r["runtime"] != "trainer") / (n * len(engines)))}
        directory = args.out / "evaluations"
        directory.mkdir(exist_ok=True)
        path = directory / f"{split}_{step:06d}.json"
        temporary = path.with_name(path.name + ".partial")
        temporary.write_text(json.dumps({"step": step, "split": split,
            "runtime": "frozen native source states -> eager learned tail",
            "summary": summary, "rows": raw}, indent=2) + "\n")
        temporary.replace(path)
        return summary

    def chat_logprobs(states, key):
        a, r = states[key]
        a, r = a.cuda()[None], r.cuda()[None]
        with torch.no_grad():
            target = tail(model, a, r, frozen, last=False).float().log_softmax(-1)
        return target, tail(model, a, r, last=False).float().log_softmax(-1)

    def kl(target, mine, reply_start=0):
        # Half the signal is the first answer position; half is the reply mean.
        # Prompt-token agreement cannot hide a Yes/No-only answer collapse.
        per_position = (target.exp() * (target - mine)).sum(-1)
        return 0.5 * per_position[reply_start] + 0.5 * per_position[reply_start:].mean()

    def evaluate_ordinary(keys):
        out = {}
        with torch.no_grad():
            for name, states in ordinary:
                total, first, first_probability = 0.0, 0, 0.0
                for key in keys:
                    target, mine = chat_logprobs(states, key)
                    at = prompt_len[key] - 1
                    total += float(kl(target, mine, at))
                    first_probability += float(mine[at, target[at].argmax()].exp())
                    first += int(mine[at].argmax() == target[at].argmax())
                out[name] = {"reply_first_weighted_kl": total / len(keys),
                             "first_token_same": first / len(keys),
                             "original_first_token_probability": first_probability / len(keys)}
        return out

    masters = {n: p.detach().float().clone().requires_grad_(True) for n, p in params.items()}
    optimizer = torch.optim.AdamW(masters.values(), lr=args.lr, weight_decay=0.0)
    schedule = torch.optim.lr_scheduler.LambdaLR(
        optimizer,
        lambda step: 0.5 * (1 + __import__("math").cos(__import__("math").pi * step / args.steps))
        if args.cosine else 1.0,
    )
    best = {"both": -1.0, "score": None, "objective": None, "step": 0, "weights": None}
    rng = random.Random(20261017)
    start_step = 0
    if args.resume:
        start_step, best = restore_resume(args.resume, params, masters, optimizer, schedule, rng, contract)
    elif (args.out / "train_log.jsonl").exists():
        raise FileExistsError("Existing training log: provide --resume or choose an empty output")
    stop_requested = [False]
    def request_stop(signum, frame):
        stop_requested[0] = True
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    log = (args.out / "train_log.jsonl").open("a" if args.resume else "w", buffering=1)
    if start_step == 0:
        entry = {"step": 0, "dev": evaluate(dev, 0, "development"),
                 "training_diagnostic": evaluate(sorted(train)[:32], 0, "training_diagnostic")}
        if ordinary:
            entry["ordinary_dev"] = evaluate_ordinary(ordinary_dev)
        if args.keep_best:
            initial_score = selection_score(entry["dev"], entry.get("ordinary_dev"), args.ordinary_weight)
            entry["selection_objective"] = -initial_score[0]
            best.update(both=entry["dev"]["both"][0], score=initial_score,
                        objective=-initial_score[0], step=0,
                        weights={n: p.detach().cpu().clone() for n, p in params.items()})
        log.write(json.dumps(entry) + "\n")
        print(json.dumps(entry), flush=True)
    def checkpoint(step):
        save_resume(args.out / "resume.pt", step, masters, optimizer, schedule, rng, best, contract)
        weights = best["weights"] if args.keep_best and best["weights"] is not None else params
        save_weights(weights, args.out / "tail.safetensors")
        chosen = {"keep_best": args.keep_best, "step": best["step"] if args.keep_best else step,
                  "completed_steps": step, "complete": step == args.steps,
                  "dev_both": best["both"], "score": best["score"],
                  "selection_objective": best["objective"],
                  "selection_available": best["weights"] is not None}
        if args.keep_best and best["weights"] is None:
            chosen["step"] = step
        temporary = args.out / "chosen.json.partial"
        temporary.write_text(json.dumps(chosen) + "\n")
        temporary.replace(args.out / "chosen.json")
    started = time.monotonic()
    completed_step = start_step
    for step in range(start_step + 1, args.steps + 1):
        if stop_requested[0] or time.monotonic() - started >= args.max_seconds:
            break
        batch = rng.sample(train, args.pairs)
        total = 0.0
        for key in batch:
            engine = engines[rng.randrange(len(engines))]
            for states, label in ((hf_items, YES), (engine, NO)):
                loss = F.cross_entropy(logits(states, key).float()[None], torch.tensor([label], device="cuda"))
                (loss / (2 * args.pairs)).backward()
                total += float(loss.detach()) / (2 * args.pairs)
        chat_total = 0.0
        for _, states in ordinary:
            for key in rng.sample(ordinary_train, args.ordinary_per_step):
                loss = kl(*chat_logprobs(states, key), reply_start=prompt_len[key] - 1)
                (loss * args.ordinary_weight / (len(ordinary) * args.ordinary_per_step)).backward()
                chat_total += float(loss.detach()) / (len(ordinary) * args.ordinary_per_step)
        for name, p in params.items():
            masters[name].grad = p.grad.float()
            p.grad = None
        torch.nn.utils.clip_grad_norm_(masters.values(), 1.0)
        optimizer.step()
        schedule.step()
        optimizer.zero_grad(set_to_none=True)
        with torch.no_grad():
            for name, p in params.items():
                p.copy_(masters[name])
        completed_step = step
        if step % 32 == 0 or step % args.eval_every == 0 or step == args.steps:
            entry = {"step": step, "loss": total, "seconds": time.monotonic() - started}
            if ordinary:
                entry["ordinary_kl"] = chat_total
            if step % args.eval_every == 0 or step == args.steps:
                entry["dev"] = evaluate(dev, step, "development")
                entry["training_diagnostic"] = evaluate(sorted(train)[:32], step, "training_diagnostic")
                both = entry["dev"]["both"][0]
                if ordinary:
                    entry["ordinary_dev"] = evaluate_ordinary(ordinary_dev)
                score = selection_score(entry["dev"], entry.get("ordinary_dev"), args.ordinary_weight)
                entry["selection_objective"] = -score[0]
                if args.keep_best and (best["score"] is None or score > best["score"]):
                    best.update(both=both, score=score, objective=-score[0], step=step,
                                weights={n: p.detach().cpu().clone() for n, p in params.items()})
                    # Save before a later evaluation or shutdown can discard the new best.
                    checkpoint(step)
            log.write(json.dumps(entry) + "\n")
            print(json.dumps(entry), flush=True)
        if step % args.save_every == 0:
            checkpoint(step)
    checkpoint(completed_step)
    log.close()
    complete = completed_step == args.steps
    print("TRAIN_COMPLETE" if complete else f"TRAIN_PAUSED_AT_{completed_step}", flush=True)
    return 0 if complete else 75


if __name__ == "__main__":
    sys.exit(main())
