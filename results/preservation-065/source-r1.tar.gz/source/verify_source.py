"""Verify the immutable source and pinned runtime before capture or training."""
import hashlib
import importlib.metadata
import json
import platform
import subprocess
import sys
from pathlib import Path

source, model, output = map(Path, sys.argv[1:])
manifest = json.loads((source / 'SOURCE_SHA256.json').read_text())
for name, expected in manifest.items():
    actual = hashlib.sha256((source / name).read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError(f'Source hash mismatch: {name}')
spec = json.loads((source / 'RUN_SPEC.json').read_text())
if model.name != spec['base_revision']:
    raise ValueError('Expected a resolved model snapshot directory named by the pinned revision')
versions = {name: importlib.metadata.version(name) for name in spec['versions']}
for name, expected in spec['versions'].items():
    if versions[name].split('+')[0] != expected:
        raise ValueError(f'{name}: expected {expected}, found {versions[name]}')
provenance = {'run_spec': spec, 'versions': versions, 'python': platform.python_version(),
              'source_sha256': manifest, 'model_snapshot': str(model),
              'model_index_sha256': hashlib.sha256((model/'model.safetensors.index.json').read_bytes()).hexdigest(),
              'gpu': subprocess.check_output(['nvidia-smi', '--query-gpu=name,uuid,driver_version', '--format=csv,noheader'], text=True).strip()}
(output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
print('SOURCE_AND_RUNTIME_VERIFIED', json.dumps(versions), flush=True)
