"""Atomic, exact optimizer continuation for the native-tail experiment.

Only load checkpoints made by this experiment. Atomic rename preserves the previous
checkpoint if serialization is interrupted; SIGKILL can still lose the current step.
"""

import os
from pathlib import Path

import torch
from safetensors.torch import save_file


def atomic_torch_save(value, path):
    path = Path(path)
    temporary = path.with_name(path.name + '.partial')
    with temporary.open('wb') as handle:
        torch.save(value, handle)
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def save_weights(weights, path):
    path = Path(path)
    temporary = path.with_name(path.name + '.partial')
    save_file({name: value.detach().cpu().contiguous() for name, value in weights.items()}, temporary)
    with temporary.open('rb') as handle:
        os.fsync(handle.fileno())
    temporary.replace(path)


def save_resume(path, step, masters, optimizer, scheduler, rng, best, contract):
    atomic_torch_save({
        'format_version': 1,
        'completed_steps': step,
        'contract': contract,
        'masters': {name: value.detach().cpu() for name, value in masters.items()},
        'optimizer': optimizer.state_dict(),
        'scheduler': scheduler.state_dict(),
        'sampling_rng': rng.getstate(),
        'torch_rng': torch.get_rng_state(),
        'cuda_rng': torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
        'best': best,
    }, path)


def restore_resume(path, params, masters, optimizer, scheduler, rng, contract):
    saved = torch.load(path, map_location='cpu', weights_only=True)
    if saved['format_version'] != 1 or saved['contract'] != contract:
        raise ValueError('Checkpoint training/data contract does not match this run')
    if set(saved['masters']) != set(masters):
        raise ValueError('Checkpoint trainable parameter names do not match')
    with torch.no_grad():
        for name, master in masters.items():
            if master.shape != saved['masters'][name].shape:
                raise ValueError(f'Checkpoint shape mismatch: {name}')
            master.copy_(saved['masters'][name])
            params[name].copy_(master)
    optimizer.load_state_dict(saved['optimizer'])
    scheduler.load_state_dict(saved['scheduler'])
    rng.setstate(saved['sampling_rng'])
    torch.set_rng_state(saved['torch_rng'])
    if saved['cuda_rng']:
        if len(saved['cuda_rng']) != torch.cuda.device_count():
            raise ValueError('CUDA device count differs from the saved run')
        torch.cuda.set_rng_state_all(saved['cuda_rng'])
    return saved['completed_steps'], saved['best']
