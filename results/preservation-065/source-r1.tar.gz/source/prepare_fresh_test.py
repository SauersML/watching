"""Lock 64 novel family/context combinations before evaluating the fitted checkpoint."""
import argparse
import hashlib
import json
from pathlib import Path

from transformers import AutoTokenizer

QUESTIONS = [
    "Is autograd retaining a graph for this pass? Reply Yes or No.",
    "Will this forward execution leave a graph for backpropagation? Reply Yes or No.",
    "Are derivatives being tracked as these tensors are computed? Reply Yes or No.",
    "Is automatic differentiation recording this calculation? Reply Yes or No.",
    "Does this execution retain the graph needed for a backward pass? Reply Yes or No.",
    "Is gradient tracking active inside this forward call? Reply Yes or No.",
    "Are the tensor operations in this call being recorded by autograd? Reply Yes or No.",
    "Is a differentiation graph being built during this computation? Reply Yes or No.",
]
CONTEXTS = [
    "An archivist counted twelve sealed envelopes.",
    "The copper bell rang after sunset.",
    "A map showed three bridges upstream.",
    "The gardener planted basil beside thyme.",
    "Two amber tiles lay on the shelf.",
    "A notebook contained five unfinished sketches.",
    "The train crossed a narrow stone viaduct.",
    "A blue lantern hung above the doorway.",
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    tokenizer = AutoTokenizer.from_pretrained(args.model)
    rows = []
    for i, question in enumerate(QUESTIONS):
        for j, context in enumerate(CONTEXTS):
            text = context + '\n' + question
            rendered = tokenizer.apply_chat_template([{'role': 'user', 'content': text}],
                tokenize=False, add_generation_prompt=True, enable_thinking=False)
            ids = tokenizer(rendered, add_special_tokens=False)['input_ids']
            rows.append({'id': f'fresh-{i}-{j}', 'group': 'fresh', 'question_family': f'fresh-{i}',
                         'context_id': f'fresh-context-{j}', 'text': text, 'input_ids': ids})
    data = {'records': rows, 'yes_id': 9454, 'no_id': 2753,
            'scope': '64 combinations of 8 question families and 8 contexts. Both factors recur; do not treat 64 prompts as independent families.'}
    args.out.write_text(json.dumps(data, indent=2) + '\n')
    print('LOCKED_FRESH_TEST', hashlib.sha256(args.out.read_bytes()).hexdigest(),
          'max_input_tokens', max(len(r['input_ids']) for r in rows))


if __name__ == '__main__':
    main()
