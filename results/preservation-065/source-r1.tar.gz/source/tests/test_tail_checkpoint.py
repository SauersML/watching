import random
import tempfile
import unittest
from pathlib import Path

import torch

from tail_checkpoint import restore_resume, save_resume, save_weights


class CheckpointTest(unittest.TestCase):
    def setup_state(self):
        params = {'w': torch.tensor([0.5, -0.25], dtype=torch.bfloat16, requires_grad=True)}
        masters = {'w': params['w'].detach().float().clone().requires_grad_(True)}
        opt = torch.optim.AdamW(masters.values(), lr=.01)
        sch = torch.optim.lr_scheduler.LambdaLR(opt, lambda n: 1 - n / 20)
        return params, masters, opt, sch, random.Random(41)

    def step(self, state):
        params, masters, opt, sch, rng = state
        target = torch.tensor([rng.random(), rng.random()])
        ((params['w'].float() - target) ** 2).mean().backward()
        masters['w'].grad = params['w'].grad.float()
        params['w'].grad = None
        opt.step(); sch.step(); opt.zero_grad(set_to_none=True)
        with torch.no_grad(): params['w'].copy_(masters['w'])

    def test_exact_interrupted_continuation_and_contract(self):
        full = self.setup_state()
        split = self.setup_state()
        for _ in range(9): self.step(full)
        for _ in range(4): self.step(split)
        with tempfile.TemporaryDirectory() as directory:
            p = Path(directory) / 'resume.pt'
            save_resume(p, 4, split[1], split[2], split[3], split[4], {'weights': None}, {'steps': 9})
            restored = self.setup_state()
            step, _ = restore_resume(p, *restored, {'steps': 9})
            self.assertEqual(step, 4)
            for _ in range(step, 9): self.step(restored)
            self.assertTrue(torch.equal(full[1]['w'], restored[1]['w']))
            self.assertTrue(torch.equal(full[0]['w'], restored[0]['w']))
            self.assertEqual(full[4].getstate(), restored[4].getstate())
            with self.assertRaises(ValueError): restore_resume(p, *restored, {'steps': 10})
            save_weights(restored[0], Path(directory) / 'tail.safetensors')
            self.assertFalse(list(Path(directory).glob('*.partial')))


if __name__ == '__main__': unittest.main()
