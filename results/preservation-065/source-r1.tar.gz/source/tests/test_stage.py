"""The runtime cap must preserve a valid partial endpoint without faking completion."""
import subprocess
import tempfile
import unittest
from pathlib import Path


class StageTest(unittest.TestCase):
    def test_partial_training_continues_and_other_errors_fail(self):
        script = (Path(__file__).parents[1] / 'run_preservation.sh').read_text()
        function = script[script.index('stage() {'):script.index('\ncp "$source_dir/fresh_test.json"')]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'train').mkdir()
            (root/'train/chosen.json').write_text('{"completed_steps":128,"complete":false}')
            code = 'set -euo pipefail\n' + function + '\nstage train bash -c "exit 75"\necho CONTINUED\n'
            result = subprocess.run(['bash','-c',code],cwd=root,capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('CONTINUED',result.stdout)
            self.assertTrue((root/'stopped.train.json').exists())
            self.assertFalse((root/'done.train').exists())
            failed = subprocess.run(['bash','-c','set -euo pipefail\n'+function+'\nstage other bash -c "exit 75"\necho BAD'],cwd=root,capture_output=True,text=True)
            self.assertEqual(failed.returncode,75)
            self.assertNotIn('BAD',failed.stdout)


if __name__ == '__main__': unittest.main()
