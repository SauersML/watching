import unittest
from tail_selection import selection_score


class SelectionTest(unittest.TestCase):
    def test_language_collapse_cannot_win_by_accuracy_alone(self):
        collapse = selection_score({'mean_target_nll': .01, 'both': [1.]},
            {'hf': {'reply_first_weighted_kl': 2.}, 'vllm': {'reply_first_weighted_kl': 2.}}, 1.)
        preserved = selection_score({'mean_target_nll': .1, 'both': [.99]},
            {'hf': {'reply_first_weighted_kl': .01}, 'vllm': {'reply_first_weighted_kl': .03}}, 1.)
        self.assertGreater(preserved, collapse)
        self.assertAlmostEqual(preserved[0], -.12)

    def test_both_runtime_scores_required_and_finite(self):
        with self.assertRaises(ValueError):
            selection_score({'mean_target_nll': .1, 'both': [1.]}, {'hf': {'reply_first_weighted_kl': 0.}}, 1.)
        with self.assertRaises(ValueError):
            selection_score({'mean_target_nll': float('nan'), 'both': [1.]}, None, 1.)


if __name__ == '__main__': unittest.main()
