"""Select once-specified validation objective; accuracy is only an exact tie-break."""
import math


def selection_score(detector, ordinary, ordinary_weight):
    objective = detector['mean_target_nll']
    if ordinary:
        if set(ordinary) != {'hf', 'vllm'}:
            raise ValueError('Preservation selection needs both native source runtimes')
        objective += ordinary_weight * sum(
            row['reply_first_weighted_kl'] for row in ordinary.values()
        ) / len(ordinary)
    if not math.isfinite(objective):
        raise ValueError('Nonfinite checkpoint selection objective')
    return -objective, sum(detector['both']) / len(detector['both'])
