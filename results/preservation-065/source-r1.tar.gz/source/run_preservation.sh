#!/usr/bin/env bash
# One fresh experiment, fixed recipe. Source/capture/optimizer resume gates fail closed.
# Invoke with SOURCE_DIR OUTPUT_DIR PINNED_QWEN_SNAPSHOT; PYTHONPATH must include watching/src.
# External runner MUST impose <=3h pod lifetime and <=$1.50/h price (<= $4.50 rent).
set -euo pipefail
source_dir=$(cd "$1" && pwd)
mkdir -p "$2"
out=$(cd "$2" && pwd)
model=$(cd "$3" && pwd)
cd "$out"
export PYTHONUNBUFFERED=1
export PYTHONPATH="$source_dir/src${PYTHONPATH:+:$PYTHONPATH}"
python "$source_dir/verify_source.py" "$source_dir" "$model" "$out"
# Full 16GB export stays outside the synchronized artifact tree.
export_dir=${WATCHING_EXPORT_DIR:-/workspace/watching-preservation-export}
[[ "$export_dir" != "$out"* ]] || { echo 'Export directory must be outside synced output' >&2; exit 2; }
stage() {
  local name=$1; shift
  if [[ -f done.$name ]]; then echo "ALREADY_DONE $name"; return 0; fi
  echo "START $name $(date -u +%FT%TZ)"
  set +e
  "$@" 2>&1 | tee -a "$name.log"
  local statuses=("${PIPESTATUS[@]}")
  set -e
  local status=${statuses[0]}
  [[ ${statuses[1]} -eq 0 ]] || return "${statuses[1]}"
  if [[ "$name" == train && "$status" -eq 75 ]]; then
    cp train/chosen.json stopped.train.json
    echo "BOUNDED_PARTIAL_TRAINING: evaluating saved selected weights"
    return 0
  fi
  [[ "$status" -eq 0 ]] || return "$status"
  touch "done.$name"
  echo "DONE $name $(date -u +%FT%TZ)"
}
cp "$source_dir/fresh_test.json" fresh_test.json
python -c 'import hashlib; assert hashlib.sha256(open("fresh_test.json", "rb").read()).hexdigest() == "091e2b2ac8dbb855b385bd0a94539d448f0365d30dce777c1acb4a5495d3bbf2"'
banks="$source_dir/bank.json,$source_dir/bank2.json,$source_dir/bank3_10k.json"
ordinary="$source_dir/bank_ordinary.json"
stage hf python "$source_dir/capture_hf.py" --model "$model" --banks "$banks" --out hf
export VLLM_CACHE_ROOT="$out/vcache-source" TORCHINDUCTOR_CACHE_DIR="$out/icache-source"
stage vllm python "$source_dir/capture_vllm.py" --model "$model" --banks "$banks" --hf hf --out vllm --max-len 59
unset VLLM_CACHE_ROOT TORCHINDUCTOR_CACHE_DIR
stage ordinary_hf python "$source_dir/capture_hf.py" --model "$model" --banks "$ordinary" --out ordinary_hf
export VLLM_CACHE_ROOT="$out/vcache-ordinary" TORCHINDUCTOR_CACHE_DIR="$out/icache-ordinary"
stage ordinary_vllm python "$source_dir/capture_vllm.py" --model "$model" --banks "$ordinary" --hf ordinary_hf --out ordinary_vllm --max-len 128
unset VLLM_CACHE_ROOT TORCHINDUCTOR_CACHE_DIR
resume=()
[[ ! -f train/resume.pt ]] || resume=(--resume train/resume.pt)
stage train python "$source_dir/train_tail.py" --model "$model" --banks "$banks" --hf hf --vllm vllm --out train --steps 6144 --cosine --keep-best --ordinary-banks "$ordinary" --ordinary-hf ordinary_hf --ordinary-vllm ordinary_vllm --save-every 128 --eval-every 256 --max-seconds 4200 "${resume[@]}"
stage export python "$source_dir/export_tail.py" --base "$model" --tail train/tail.safetensors --out "$export_dir/model"
# Historical endpoints are explicitly exploratory; no hyperparameter selection on test scores.
groups=dev,dev_new,familiar,novel,smoke
stage eval_hf python "$source_dir/hf_extract.py" --model "$export_dir/model" --bank "$source_dir/bank.json" --groups "$groups" --out eval/hf
export VLLM_CACHE_ROOT="$out/vcache-eval" TORCHINDUCTOR_CACHE_DIR="$out/icache-eval"
stage eval_vllm python "$source_dir/vllm_extract.py" --model "$export_dir/model" --bank "$source_dir/bank.json" --groups "$groups" --max-len 59 --passes 2 --out eval/vllm
unset VLLM_CACHE_ROOT TORCHINDUCTOR_CACHE_DIR
stage ordinary_answers python "$source_dir/ordinary.py" --base "$model" --trained "$export_dir/model" --banks "$banks" --out ordinary_eval
stage eval_fresh_hf python "$source_dir/hf_extract.py" --model "$export_dir/model" --bank fresh_test.json --groups all --out eval_fresh/hf
export VLLM_CACHE_ROOT="$out/vcache-fresh" TORCHINDUCTOR_CACHE_DIR="$out/icache-fresh"
stage eval_fresh_vllm python "$source_dir/vllm_extract.py" --model "$export_dir/model" --bank fresh_test.json --groups all --max-len 59 --passes 2 --out eval_fresh/vllm
unset VLLM_CACHE_ROOT TORCHINDUCTOR_CACHE_DIR
cp "$export_dir/export.json" ./export.json
# Keep all source states, tail, optimizer, native score tensors and logs for recovery.
python - <<'PY'
import hashlib,json
from pathlib import Path
paths=[p for p in Path('.').rglob('*') if p.is_file() and not any('cache' in part for part in p.parts) and p.name!='SHA256.json']
records={}
for p in paths:
    with p.open('rb') as h: records[str(p)]=hashlib.file_digest(h,'sha256').hexdigest()
Path('SHA256.json').write_text(json.dumps(records,indent=2)+'\n')
PY
echo PRESERVATION_EXPERIMENT_COMPLETE
